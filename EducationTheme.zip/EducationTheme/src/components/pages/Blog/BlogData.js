import img1 from "../../../assets/Gallery/Gallery01.jpg"
import img2 from "../../../assets/Gallery/Gallery02.jpg"
import img3 from "../../../assets/Gallery/Gallery03.jpg"
import img4 from "../../../assets/Gallery/Gallery04.jpg"
import img5 from "../../../assets/Gallery/Gallery05.jpg"
import img6 from "../../../assets/Gallery/Gallery06.jpg"
import img7 from "../../../assets/Gallery/Gallery07.jpg"
import img8 from "../../../assets/Gallery/Gallery08.jpg"
import { BsPersonCircle } from "react-icons/bs";
import { BsCalendar4 } from "react-icons/bs";


export const BlogData = [
    {
        id: 1,
        image: img1,
        title: "  Why Play Is Important in Preschool and Early",
        text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },

    {
        id: 2,
        image: img2,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },
    {
        id: 3,
        image: img3,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },
    {
        id: 4,
        image: img4,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },
    {
        id: 5,
        image: img5,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },
    {
        id: 6,
        image: img6,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },
    {
        id: 7,
        image: img7,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },
    {
        id: 8,
        image: img8,
        title: "  Why Play Is Important in Preschool and Early",
         text: "  Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.",
        name: "Jone Smit",
        Date: "July 1, 2020",
        profileicon: <BsPersonCircle/>,
        calicon:<BsCalendar4/>
    },

]