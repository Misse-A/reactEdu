import React from "react";

export const Head = () => {
  return (
    <>
      <div className="DLMainBox">
        <div className="DLearingBox1 DLBoxtext a-one animate">
          <div className="DLBox1">
            <h6>1,589</h6>
            <p>FINISHED SESSIONS</p>
          </div>
        </div>
        <div className="DLearingBox3 DLBoxtext b-one animate">
          <div className="DLBox2  ">
            <h6>50</h6>
            <p>ONLINE INSTRUCTORS</p>
          </div>
        </div>
      </div>
    </>
  );
};
