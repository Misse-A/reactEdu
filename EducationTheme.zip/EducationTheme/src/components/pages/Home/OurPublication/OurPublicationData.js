import img1 from "../../../../assets/OurPublication/OurPImg1.png";
import { BsCalendarEvent } from "react-icons/bs";


export const OurPublicationData = [
    {
        id: 1,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 2,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 3,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 4,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 5,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 6,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 7,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 8,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    },
    {
        id: 9,
        image: img1,
        title: "Education",
        text: " Join ATD 2021 International Conference & Export.",
        subtext:" Explore all of our courses and pick your suitable ones to enroll and start learning.",
        calicon: <BsCalendarEvent />,
        date:"2021-05-06"
    }
]